import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";
import { AlertController, ToastController, LoadingController } from '@ionic/angular';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.page.html',
  styleUrls: ['./logout.page.scss'],
})
export class LogoutPage implements OnInit {
  myform: FormGroup;
  private user = environment.userid;
  private key = environment.apikey;
  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router, private alertCtrl: AlertController,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController) { }

  ngOnInit() {
    this.myform = this.fb.group({
      userid: [""],
      apikey: [''],
      phone: new FormControl('', Validators.required),
      session_id: ['']
    })
  }

  async  onSubmit() {
    console.log(this.myform.value)

    this.myform.value.userid = this.user;
    this.myform.value.apikey = this.key;
    const sessionID=localStorage.getItem('session_id')
    this.myform.value.session_id=sessionID;
    const loading = await this.loadingCtrl.create({ message: 'Requesting...' });
    await loading.present();
    this.authService.logout(this.myform.value).subscribe(

      async (data) => {
        if (data.SUCCESS == "YES") {
        
          loading.dismiss();
          localStorage.removeItem("session_id");

          this.router.navigate(['/home']);
          this.myform.reset();
        }
        else {
          const alert = await this.alertCtrl.create({ message: '"SUCCESS:NO"', buttons: ['OK'] });
          loading.dismiss();
          await alert.present();
        }
      }
    )
  }

}
