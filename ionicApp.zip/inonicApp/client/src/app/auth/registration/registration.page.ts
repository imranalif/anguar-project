import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";
import { AuthService } from '../auth.service';
import { AlertController, ToastController, LoadingController } from '@ionic/angular';
import { HTTP } from '@ionic-native/http/ngx'
import { from } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.page.html',
  styleUrls: ['./registration.page.scss'],
})
export class RegistrationPage {
  private user = environment.userid;
  private key = environment.apikey;
  constructor(private fb: FormBuilder, private authService: AuthService, private alertCtrl: AlertController,
    private toastCtrl: ToastController, private nativeHttp: HTTP,
    private loadingCtrl: LoadingController) { }

  myform = new FormGroup({
    userid: new FormControl(''),
    apikey: new FormControl(''),
    name: new FormControl('', [Validators.required]),
    email: new FormControl(''),
    phone: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
    address: new FormControl('')
  })



  async onSubmit() {
    console.log(this.myform.value)
    this.myform.value.userid = this.user;
    this.myform.value.apikey = this.key;
    const loading = await this.loadingCtrl.create({ message: 'Registering...' });
    await loading.present();


    this.authService.register(this.myform.value).subscribe(

      async (data) => {
        if (data.SUCCESS == "YES") {
          const toast = await this.toastCtrl.create({ message: "SUCCESS:YES", duration: 2000, color: 'dark' });
          await toast.present();
          loading.dismiss();
          this.myform.reset();
        }
        else {
          const alert = await this.alertCtrl.create({ message: '"SUCCESS:NO"', buttons: ['OK'] });
          loading.dismiss();
          await alert.present();
        }
      },


    )
  }

}
