import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {HTTP} from '@ionic-native/http/ngx'
import { User } from './user.model';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  //private urla:environment.userid;
  constructor(private http: HttpClient,private nativeHttp:HTTP,private router: Router) { }
  private url = 'http://localhost:3000';
  

   register(user:User){
    return this.http.post<any>(this.url+'/register', user);
  }

  // register(user:User){
  //   return this.nativeHttp.post(this.url+'/register', user,{}).pipe();
  // }
  login(data:User){
    return this.http.post<any>(this.url+'/login', data);
  }

  logout(data:User){
    return this.http.post<any>(this.url+'/logout', data);
  }

  // logout() {
  //   localStorage.removeItem("token");
  //   //localStorage.removeItem("data");
  //   this.router.navigate(["/login"]);
  // }
}
