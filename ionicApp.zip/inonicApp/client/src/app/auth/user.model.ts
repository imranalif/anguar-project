export interface User{
    userid:string,
    apikey:string,
    name:string,
    email:string,
    phone:string,
    password:string,
    address:string
}