import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { AlertController, ToastController, LoadingController } from '@ionic/angular';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  myform: FormGroup;
  private user = environment.userid;
  private key = environment.apikey;
  a = 2323;
  sDefaultEmail: string;
  show: any;
  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router,
    private toastCtrl: ToastController, private alertCtrl: AlertController,
    private loadingCtrl: LoadingController) { this.sDefaultEmail = 'duapp'; }



  ngOnInit() {
    this.myform = this.fb.group({
      userid: [""],
      apikey: [''],
      phone: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    })
  }

  async onSubmit() {
    console.log(this.myform.value)
    this.myform.value.userid = this.user;
    this.myform.value.apikey = this.key;
    const loading = await this.loadingCtrl.create({ message: 'Registering...' });
    await loading.present();
    this.authService.login(this.myform.value).subscribe(

      async (data) => {
        if (data.SUCCESS == "YES") {

          loading.dismiss();
          localStorage.setItem('session_id', data.session_id);
          this.router.navigate(['/welcome']);
          this.myform.reset();
        }
        else {
          console.log(data)
          const alert = await this.alertCtrl.create({ message: '"SUCCESS:NO"', buttons: ['OK'] });
          //const alert = await this.alertCtrl.create({ message:data.ERROR, buttons: ['OK'] });
          loading.dismiss();
          await alert.present();
        }
      },

    )

  }

}
