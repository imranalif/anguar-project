import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TotalAvailablePageRoutingModule } from './total-available-routing.module';

import { TotalAvailablePage } from './total-available.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,ReactiveFormsModule,
    IonicModule,
    TotalAvailablePageRoutingModule
  ],
  declarations: [TotalAvailablePage]
})
export class TotalAvailablePageModule {}
