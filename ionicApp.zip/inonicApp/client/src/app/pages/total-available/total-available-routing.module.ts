import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TotalAvailablePage } from './total-available.page';

const routes: Routes = [
  {
    path: '',
    component: TotalAvailablePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TotalAvailablePageRoutingModule {}
