import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";
import { AlertController, ToastController, LoadingController } from '@ionic/angular';
import { PageService } from '../page.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-total-available',
  templateUrl: './total-available.page.html',
  styleUrls: ['./total-available.page.scss'],
})
export class TotalAvailablePage implements OnInit {

  myform: FormGroup;
  PageService: any;
  data: any
  private user = environment.userid;
  private key = environment.apikey;
  constructor(private fb: FormBuilder, private alertCtrl: AlertController,
    private toastCtrl: ToastController, private pageService: PageService,
    private loadingCtrl: LoadingController) { }

  ngOnInit() {
    this.myform = this.fb.group({
      userid: [""],
      apikey: [''],


    })

    this.onSubmit()
  }


  onSubmit() {
    console.log(this.myform.value)
    this.myform.value.userid = this.user;
    this.myform.value.apikey = this.key;
    this.pageService.totalAvailable(this.myform.value).subscribe(
      res => {

        this.data = res

      }
    )
  }

}
