import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { TotalAvailablePage } from './total-available.page';

describe('TotalAvailablePage', () => {
  let component: TotalAvailablePage;
  let fixture: ComponentFixture<TotalAvailablePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TotalAvailablePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(TotalAvailablePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
