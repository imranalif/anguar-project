import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CallStatusPageRoutingModule } from './call-status-routing.module';

import { CallStatusPage } from './call-status.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,ReactiveFormsModule,
    IonicModule,
    CallStatusPageRoutingModule
  ],
  declarations: [CallStatusPage]
})
export class CallStatusPageModule {}
