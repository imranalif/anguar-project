import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";
import { AlertController, ToastController, LoadingController } from '@ionic/angular';
import { PageService } from '../page.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-call-status',
  templateUrl: './call-status.page.html',
  styleUrls: ['./call-status.page.scss'],
})
export class CallStatusPage implements OnInit {

  myform: FormGroup;
  PageService: any;

  private user = environment.userid;
  private key = environment.apikey;
  constructor(private fb: FormBuilder, private alertCtrl: AlertController,
    private toastCtrl: ToastController, private pageService: PageService,
    private loadingCtrl: LoadingController) { }

  ngOnInit() {
    this.myform = this.fb.group({
      userid: [""],
      apikey: [''],
      phone: new FormControl('', Validators.required),

    })
  }

  async onSubmit() {
    console.log(this.myform.value)
    this.myform.value.userid = this.user;
    this.myform.value.apikey = this.key;
    const loading = await this.loadingCtrl.create({ message: 'Registering...' });
    await loading.present();
    this.pageService.callStatus(this.myform.value).subscribe(


      async (data) => {
        console.log(data)
        if (data.STATUS == "1") {
          const toast = await this.toastCtrl.create({ message: "STATUS:1", duration: 2000, color: 'dark' });
          await toast.present();
          loading.dismiss();
          this.myform.reset();
        }
        else {
          const toast = await this.toastCtrl.create({ message: "STATUS:0", duration: 2000, color: 'dark' });
          await toast.present();
          loading.dismiss();;
        }
      }
    )
  }

}
