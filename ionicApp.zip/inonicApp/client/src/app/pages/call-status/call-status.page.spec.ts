import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { CallStatusPage } from './call-status.page';

describe('CallStatusPage', () => {
  let component: CallStatusPage;
  let fixture: ComponentFixture<CallStatusPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CallStatusPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(CallStatusPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
