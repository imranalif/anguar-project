import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../auth/user.model';

@Injectable({
  providedIn: 'root'
})
export class PageService {

  constructor(private http: HttpClient) { }
  private url = 'http://119.40.81.22:80/doctor';

  callAllow(data:User){
    return this.http.post<any>(this.url+'/callallow', data);
  }

  callStatus(data:User){
    return this.http.post<any>(this.url+'/callAllowStatus', data);
  }

  totalAvailable(data:User){
    return this.http.post<any>(this.url+'/TotalAvailable', data);
  }
}
