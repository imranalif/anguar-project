import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";
import { AlertController, ToastController, LoadingController } from '@ionic/angular';
import { PageService } from '../page.service';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-call-permission',
  templateUrl: './call-permission.page.html',
  styleUrls: ['./call-permission.page.scss'],
})
export class CallPermissionPage implements OnInit {
  myform: FormGroup;
  PageService: any;
  private user = environment.userid;
  private key = environment.apikey;
  constructor(private fb: FormBuilder, private alertCtrl: AlertController,
    private toastCtrl: ToastController, private pageService: PageService,
    private loadingCtrl: LoadingController) { }

  ngOnInit() {
    this.myform = this.fb.group({
      userid: [""],
      apikey: [''],
      phone: new FormControl('', Validators.required),
      callallow: new FormControl('', Validators.required),
      session_id: ['']
    })
  }



  async onSubmit() {
    console.log(this.myform.value)
    this.myform.value.userid = this.user;
    this.myform.value.apikey = this.key;
    const sessionID=localStorage.getItem('session_id')
    this.myform.value.session_id=sessionID;
    const loading = await this.loadingCtrl.create({ message: 'Registering...' });
    await loading.present();
    this.pageService.callAllow(this.myform.value).subscribe(
      async (data) => {
        if (data.SUCCESS == "YES") {
          const toast = await this.toastCtrl.create({ message: "SUCCESS:YES", duration: 2000, color: 'dark' });
          await toast.present();
          loading.dismiss();
          this.myform.reset();
        }
        else {
          const alert = await this.alertCtrl.create({ message: '"SUCCESS:NO"', buttons: ['OK'] });
          loading.dismiss();
          await alert.present();
        }
      },
    )
  }


}
