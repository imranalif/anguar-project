import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CallPermissionPage } from './call-permission.page';

const routes: Routes = [
  {
    path: '',
    component: CallPermissionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CallPermissionPageRoutingModule {}
