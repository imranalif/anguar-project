import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CallPermissionPageRoutingModule } from './call-permission-routing.module';

import { CallPermissionPage } from './call-permission.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,ReactiveFormsModule,
    IonicModule,
    CallPermissionPageRoutingModule
  ],
  declarations: [CallPermissionPage]
})
export class CallPermissionPageModule {}
