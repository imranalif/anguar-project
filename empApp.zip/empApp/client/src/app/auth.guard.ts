import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AppService } from './model/app.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private _route: Router, private _dept: AppService) {}

  canActivate(): boolean {
    if (this._dept.loggedIn()) {
      return true;
    } else {
      this._route.navigate(["/auth/login"]);
      return false;
    }
  }
  
}
