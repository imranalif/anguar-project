export class Employee {
    firstName: String;
  lastName: String;
  employeeId: String;
  mobile: String;
  email: String;
  address: String;
  department: String;
  degination: String;
  role: String;
  gender: String;
  image: any;
  password: String;
  status: String;
}
