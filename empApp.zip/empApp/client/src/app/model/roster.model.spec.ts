import { Roster } from './roster.model';

describe('Roster', () => {
  it('should create an instance', () => {
    expect(new Roster()).toBeTruthy();
  });
});
