import { Offday } from './offday.model';

describe('Offday', () => {
  it('should create an instance', () => {
    expect(new Offday()).toBeTruthy();
  });
});
