export class Offday {
    title: String;
    type: String;
    date: String;
    status: String;
}
