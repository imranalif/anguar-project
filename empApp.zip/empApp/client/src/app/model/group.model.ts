export class Group {
    name: String;
    
    status: String;
}
