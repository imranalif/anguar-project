export class EmpShift {
    department:String;
    employee:String
    shift:String
    frdate:String
    todate:String
    status:String
}
