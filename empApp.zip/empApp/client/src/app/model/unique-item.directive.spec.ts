import { UniqueItemDirective } from './unique-item.directive';

describe('UniqueItemDirective', () => {
  it('should create an instance', () => {
    const directive = new UniqueItemDirective();
    expect(directive).toBeTruthy();
  });
});
