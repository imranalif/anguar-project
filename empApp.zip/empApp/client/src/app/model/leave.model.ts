export class Leave {
    department: String;
  employee: String;
  type: String;
  frdate: String;
  todate: String;
  reason: String;
  status: String;
}
