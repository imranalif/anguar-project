import { Department } from './department.model';

describe('Department', () => {
  it('should create an instance', () => {
    expect(new Department()).toBeTruthy();
  });
});
