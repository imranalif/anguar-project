import { Injectable } from '@angular/core';
import { HttpClient,HttpEventType,HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { Department } from './department.model';
import { Degination } from './degination.model';
import {Role } from './role.model';
import { Employee } from './employee.model';
import { Shift } from './shift.model';
import { CSVRecord } from './csvrecord.model';
import { Offday } from './offday.model';
import { Roster } from './roster.model';
import { Leave } from './leave.model';
import { Group } from './group.model';
import { analytics } from '@angular-devkit/core';
import { Permission } from './permission.model';
import { EmpShift } from './emp-shift.model';
import { Login } from './login.model';
import { map } from  'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class AppService {
  emps: Employee[];
  emp:Employee
  constructor(private _http: HttpClient, private _router: Router) {}

  private url = 'http://localhost:3000/api/';

  groups:Group[]

  /*-------------------------------------Department-------------------------------------------*/
  addDept(dept: Department) {
    return this._http.post(this.url, dept);
  }

  getDept() {
    return this._http.get(this.url+ '/dept');
  }

  getDeptByPage(page) {
    return this._http.get(this.url+page + '/deptByPage');
  }

  getDeptId(id: string) {
    return this._http.get(this.url + id + '/dept');
  }

  updateDept(id: string, dept: Department) {
    return this._http.put(this.url + id + '/dept', dept);
  }

  deleteDept(id: string) {
    return this._http.delete(this.url + id);
  }

  getDeptName(item:string){
    return this._http.get<any[]>(this.url + item + '/dept/itm');
  }

  /*-------------------------------------Degination-------------------------------------------*/
  addDegi(degi: Degination) {
    return this._http.post(this.url + '/dept/degi', degi);
  }

  getDegiId(id: string) {
    return this._http.get(this.url + id + '/dept/degi');
  }

  getDegi() {
    return this._http.get(this.url + '/dept/degi');
  }

  updateDegi(id: string,degi: Degination){
    return this._http.put(this.url + id + '/degiUpdate', degi);
  }


 /*-------------------------------------User Role-------------------------------------------*/

 addRole(role: Role) {
  return this._http.post(this.url+'/dept/degi/role', role);
}

getRole() {
  return this._http.get(this.url + '/dept/degi/role');
}

getRoleId(id:string){
  return this._http.get(this.url + id + '/dept/degi/role');
}

updateRole(id:string,role: Role){
  return this._http.put(this.url + id + '/roleUpdate', role);
}

/*-------------------------------------Employee-------------------------------------------*/

// addEmp(emp: Employee,data:any) {
//   return this._http.post(this.url+'/addEmployee',emp);
// }




addEmp(data:any) {
  return this._http.post<any>(this.url+'/addEmployee',data,{
    reportProgress:true,
    observe:"events"
  }).pipe(map((event) => {

    switch (event.type) {

      case HttpEventType.UploadProgress:
        const progress = Math.round(100 * event.loaded / event.total);
        return { status: 'progress', message: progress };

      case HttpEventType.Response:
        return event.body;
      default:
        return `Unhandled event: ${event.type}`;
    }
  }))
}

getEmployee(currentPage){
 
  //let search={pageSize:empPerPage,page:currentPage}
  //const queryParams=`?pageSize=${empPerPage}&page=${currentPage}`

  return this._http.get(this.url+currentPage+"/getEmployee" );
}

getEmpId(id:string){
  return this._http.get(this.url + id + '/editEmp');
}

updateEmp(id:string,emp: Employee){
  return this._http.put(this.url + id + '/updateEmp', emp);
}
/*-------------------------------------Shift-------------------------------------------*/

addShift(shift:Shift){
  return this._http.post(this.url+'/dept/degi/role/emp/shift', shift);
}
getShift(){
  return this._http.get(this.url + '/dept/degi/role/emp/shift');
}
getShiftId(id:string){
  return this._http.get(this.url + id + '/editShift');
}

updateShift(id:string,shift:Shift){
  return this._http.put(this.url + id + '/updateShift', shift);
}

deleteShift(id: string) {
  return this._http.delete(this.url + id+'/deleteShift');
}

/*-------------------------------------offday ---------------------------------------*/

addOffDay(offday:Offday){
  return this._http.post(this.url+'/addOffday', offday);

}

getOffDay(){
 
    return this._http.get(this.url + '/listOffday');
 
}

getOffdayId(id:string){
  return this._http.get(this.url + id + '/editOffday');
}



/*-------------------------------------Employee Roster-------------------------------------*/

getEmpByDept(name:string){
  return this._http.get(this.url + name+"/dept/degi/role/emp/shift" );
}
addRoster(roster:Roster){
  return this._http.post(this.url+'/dept/degi/role/emp/shift/roster', roster);
}

getEmpRoster(){
  return this._http.get(this.url +"/dept/degi/role/emp/shift/roster" );
}

getRosterId(id:string){
  return this._http.get(this.url + id + '/editRoster');
}

updateRoster(id:string,roster:Roster){
  return this._http.put(this.url + id + '/rosterUpdate', roster);
}

/*-------------------------------------Leave-------------------------------------*/

addLeave(leave:Leave){
  return this._http.post(this.url+'/dept/degi/role/emp/shift/roster/leave', leave); 
}

getLeave(){
  return this._http.get(this.url +"/leave" )
}

getLeaveId(id:string){
  return this._http.get(this.url + id + '/editLeave');
}

updateLeave(id:string,leave:Leave){
  return this._http.put(this.url + id + '/updateLeave', leave);
}

deleteLeave(id:string){
  return this._http.delete(this.url + id+'/deleteLeave'); 
}

/*-------------------------------------Employee Shift ---------------------------------------*/

addEmpShift(empShift:EmpShift){
  return this._http.post(this.url+'/empShift', empShift);
}

getEmpShift(){
  return this._http.get(this.url +"/empShift" );
}


/*-------------------------------------Group-------------------------------------*/
addGroup(group:Group){
  return this._http.post(this.url+'/dept/degi/role/emp/shift/roster/leave/group', group); 
}
getGroup(){
  return this._http.get(this.url +"/dept/degi/role/emp/shift/roster/leave/group" )
}

getGroupId(id:string){
  return this._http.get(this.url + id + '/editGroup');
}

updateGroup(id:string,group:Group){
  return this._http.put(this.url + id + '/updateGroup', group);
}

deleteGroup(id: string) {
  return this._http.delete(this.url + id+'/deleteGroup');
}


/*-------------------------------------Permission-------------------------------------*/

addPermi(permi:Permission){
  return this._http.post(this.url+'/dept/degi/role/emp/shift/roster/leave/group/perm', permi);
}

getPermiItem(name:string){
  return this._http.get(this.url+name +"/finditem" )
}
getPermi(){
  return this._http.get(this.url +"/listPermi" )
}

getPermiId(id:string){
  return this._http.get(this.url + id + '/editPermi');
}

updatePermi(id:string,permi:Permission){
  return this._http.put(this.url + id + '/updatePermi', permi);
}

deletePermi(id: string) {
  return this._http.delete(this.url + id+'/deletePermi');
}

/*-------------------------------------login-------------------------------------*/

loginEmp(login:Login){
  return this._http.post<any>(this.url+'/loginEmp', login);
}

loggedIn() {
  return !!localStorage.getItem("token");
}
logoutEmp() {
  localStorage.removeItem("token");
  this._router.navigate(["/auth/login"]);
}

getToken() {
  return localStorage.getItem("token");
}

}