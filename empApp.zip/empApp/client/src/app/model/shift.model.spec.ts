import { Shift } from './shift.model';

describe('Shift', () => {
  it('should create an instance', () => {
    expect(new Shift()).toBeTruthy();
  });
});
