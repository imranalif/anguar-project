import { EmpShift } from './emp-shift.model';

describe('EmpShift', () => {
  it('should create an instance', () => {
    expect(new EmpShift()).toBeTruthy();
  });
});
