export class Shift {
    name:String;
    description:String;
    start:String;
    end:String;
    grace:String;
    logout:String;
    status:String
}
