import { Permission } from './permission.model';

describe('Permission', () => {
  it('should create an instance', () => {
    expect(new Permission()).toBeTruthy();
  });
});
