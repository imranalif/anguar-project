export class Department {
    name: String;
    description: String;
    status: String;
}
