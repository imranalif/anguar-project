import { Degination } from './degination.model';

describe('Degination', () => {
  it('should create an instance', () => {
    expect(new Degination()).toBeTruthy();
  });
});
