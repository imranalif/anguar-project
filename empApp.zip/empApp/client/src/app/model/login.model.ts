export class Login {
    empployeeId: String;
    password: String;
}
