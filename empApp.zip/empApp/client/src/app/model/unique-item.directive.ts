import { Directive } from '@angular/core';
import { Observable, timer } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import {
  AsyncValidator,
  AbstractControl,
  ValidationErrors,
  Validators,
  NG_ASYNC_VALIDATORS,
  AsyncValidatorFn,
} from '@angular/forms';
import { promise } from 'protractor';
import { AppService } from './app.service';

export function UniqueItemValidator(_name: AppService): AsyncValidatorFn {
  return (
    c: AbstractControl
  ): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> => {
    return _name.getDeptName(c.value).pipe(
      map(res => {
        console.log(res);
        //console.log(res.length);
        // if(res.length)
        // return { 'userNameExists': true};
        if(res)
        return { 'UniqueItem': true};
        //return res && res.length > 0 ? { UniqueItem: true } : null;
      })
    );
  };
}


@Directive({
  selector: '[UniqueItem]',
  providers: [
    { provide: NG_ASYNC_VALIDATORS, useExisting: UniqueItemDirective, multi: true },
  ],
})
export class UniqueItemDirective {

  constructor(private _name: AppService) { }

  validate(
    c: AbstractControl
  ): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> {
    return this._name.getDeptName(c.value).pipe(
      map(res => {
        // if(res.length)
        // return { 'userNameExists': true};
        return res && res.length > 0 ? { 'UniqueItem': true } : null;
      })
    );
  }
}



