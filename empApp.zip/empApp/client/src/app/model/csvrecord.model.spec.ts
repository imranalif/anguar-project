import { CSVRecord } from './csvrecord.model';

describe('CSVRecord', () => {
  it('should create an instance', () => {
    expect(new CSVRecord()).toBeTruthy();
  });
});
