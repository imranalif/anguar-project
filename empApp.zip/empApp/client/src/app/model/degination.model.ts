export class Degination {
  name: String;
  description: String;
  status: String;
}
