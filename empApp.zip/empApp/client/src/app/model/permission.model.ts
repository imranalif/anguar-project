export class Permission {
    gname:String;
    //name: String;
    item: String;
    order:String;
    status: String;
}
