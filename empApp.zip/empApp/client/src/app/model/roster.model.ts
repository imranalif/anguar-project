export class Roster {
    department:String;
    employee:String
    shift:String
    frdate:String
    todate:String
    status:String
}
