export class Role {
    name: String;
    description: String;
    status: String;
}
