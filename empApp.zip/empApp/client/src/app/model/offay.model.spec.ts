import { Offay } from './offay.model';

describe('Offay', () => {
  it('should create an instance', () => {
    expect(new Offay()).toBeTruthy();
  });
});
