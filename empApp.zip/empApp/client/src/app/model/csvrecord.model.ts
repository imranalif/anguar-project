export class CSVRecord {
    id:any
    uniqueID:any
    enterqueue:any
    connect:any
    caller:any
    hunting:any
    agent:any
    extension:any
    campaign:any
    ivr:any
    wait:any
    coTime:any
    rTime:any
    tTime:any
    rna:any
    transfer:any
    status:any
    cby:any
    cTime:any
   
}
