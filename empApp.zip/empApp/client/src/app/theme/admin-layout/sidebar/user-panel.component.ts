import { Component } from '@angular/core';
import { AppService } from 'app/model/app.service';

@Component({
  selector: 'app-user-panel',
  template: `
    <div
      class="matero-user-panel p-y-16 b-t-1 b-b-1"
      fxLayout="column"
      fxLayoutAlign="center center"
    >
      <img
        class="matero-user-panel-avatar m-b-8 r-full"
        src="assets/uploads/1571865838261-bbgdgdgd.jpeg"
        alt="avatar"
        width="64"
      />
      <h4 class="matero-user-panel-name m-t-0 m-b-8 f-w-400">{{this.data2.firstName}}</h4>
      <h5 class="matero-user-panel-email m-t-0 m-b-8 f-w-400">{{this.data2.email}}</h5>
      <div class="matero-user-panel-icons text-nowrap">
        <a routerLink="/profile/overview" mat-icon-button>
          <mat-icon class="icon-18">account_circle</mat-icon>
        </a>
        <a routerLink="/profile/settings" mat-icon-button>
          <mat-icon class="icon-18">settings</mat-icon>
        </a>
        <a routerLink="/auth/login" mat-icon-button>
          <mat-icon class="icon-18">exit_to_app</mat-icon>
        </a>
      </div>
    </div>
  `,
})
export class UserPanelComponent {
  data2:{}
  constructor(private _app:AppService){

  }

  ngOnInit() {
    const data1=localStorage.getItem("data");
    this.data2 = JSON.parse(data1);
    console.log(this.data2)
  }
}
