import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateEmpshiftComponent } from './update-empshift.component';

describe('UpdateEmpshiftComponent', () => {
  let component: UpdateEmpshiftComponent;
  let fixture: ComponentFixture<UpdateEmpshiftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateEmpshiftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateEmpshiftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
