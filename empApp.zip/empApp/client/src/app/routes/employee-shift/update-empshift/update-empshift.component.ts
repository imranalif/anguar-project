import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-empshift',
  templateUrl: './update-empshift.component.html',
  styleUrls: ['./update-empshift.component.scss']
})
export class UpdateEmpshiftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
