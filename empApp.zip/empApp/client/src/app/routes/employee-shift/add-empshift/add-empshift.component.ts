import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppService } from 'app/model/app.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-empshift',
  templateUrl: './add-empshift.component.html',
  styleUrls: ['./add-empshift.component.scss']
})
export class AddEmpshiftComponent implements OnInit {
  myform: FormGroup;
  data:{}
  data1: {};
  data2: {};

  states = [{ value: "active" }, { value: "inActive" }];

  constructor(private fb: FormBuilder, private _empShift: AppService, private toastr: ToastrService) { }

  ngOnInit() {
    this.myform = this.fb.group({
      department: [""],
      employee: [""],
      shift: [""],
      frdate: [""],
      todate: [""],
      status: [""]
    });
    this._empShift.getDept().subscribe(res => {
      this.data1 = res ;
    });
    this._empShift.getShift().subscribe(res => {
      this.data2 = res ;
    });
  }

  onChange(name: string) {
    this._empShift.getEmpByDept(name).subscribe(res => {
      //this._eshift.emps = res as Employee[];
      this.data = res;
    });
  }

  addEmpShift(){
    this._empShift.addEmpShift(this.myform.value).subscribe()
  }

}
