import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEmpshiftComponent } from './add-empshift.component';

describe('AddEmpshiftComponent', () => {
  let component: AddEmpshiftComponent;
  let fixture: ComponentFixture<AddEmpshiftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEmpshiftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEmpshiftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
