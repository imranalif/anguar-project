import { Component, OnInit } from '@angular/core';
import { AppService } from 'app/model/app.service';

@Component({
  selector: 'app-list-empshift',
  templateUrl: './list-empshift.component.html',
  styleUrls: ['./list-empshift.component.scss']
})
export class ListEmpshiftComponent implements OnInit {
  data:{}

  constructor(private _empShift:AppService) { }

  ngOnInit() {

    this._empShift.getEmpShift().subscribe(res => {
      this.data = res;
    });
  }

  displayedColumns = [
    "department",
    "employee",
    "shift",
    "frdate",
    "todate",
    "status",
    "action"
  ]

}
