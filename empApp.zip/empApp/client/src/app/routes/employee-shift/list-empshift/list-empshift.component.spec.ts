import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListEmpshiftComponent } from './list-empshift.component';

describe('ListEmpshiftComponent', () => {
  let component: ListEmpshiftComponent;
  let fixture: ComponentFixture<ListEmpshiftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListEmpshiftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListEmpshiftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
