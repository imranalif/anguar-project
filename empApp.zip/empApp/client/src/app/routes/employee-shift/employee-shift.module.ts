import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeeShiftRoutingModule } from './employee-shift-routing.module';
import { AddEmpshiftComponent } from './add-empshift/add-empshift.component';
import { ListEmpshiftComponent } from './list-empshift/list-empshift.component';
import { UpdateEmpshiftComponent } from './update-empshift/update-empshift.component';
import { SharedModule } from '@shared/shared.module';
import { MaterialModule } from '../material/material.module';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [AddEmpshiftComponent, ListEmpshiftComponent, UpdateEmpshiftComponent],
  imports: [
    CommonModule,
    SharedModule,
    MaterialModule,
    ReactiveFormsModule,
    EmployeeShiftRoutingModule
  ]
})
export class EmployeeShiftModule { }
