import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddEmpshiftComponent } from './add-empshift/add-empshift.component';
import { ListEmpshiftComponent } from './list-empshift/list-empshift.component';
import { UpdateEmpshiftComponent } from './update-empshift/update-empshift.component';


const routes: Routes = [{ path: 'addEmpShift', component: AddEmpshiftComponent },
{ path: 'listEmpShift', component: ListEmpshiftComponent },
{ path: 'editEmpShift/:id', component: UpdateEmpshiftComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmployeeShiftRoutingModule { }
