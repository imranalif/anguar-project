import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddLeaveComponent } from './add-leave/add-leave.component';
import { ListLeaveComponent } from './list-leave/list-leave.component';
import { UpdateLeaveComponent } from './update-leave/update-leave.component';


const routes: Routes = [
  { path: 'add', component: AddLeaveComponent },
{ path: 'listLeave', component: ListLeaveComponent },
{ path: 'editLeave/:id', component: UpdateLeaveComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LeaveRoutingModule { }
