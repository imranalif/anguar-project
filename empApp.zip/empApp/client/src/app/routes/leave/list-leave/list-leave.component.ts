import { Component, OnInit } from '@angular/core';
import { AppService } from 'app/model/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-leave',
  templateUrl: './list-leave.component.html',
  styleUrls: ['./list-leave.component.scss']
})
export class ListLeaveComponent implements OnInit {
  data:{}

  constructor(private _leave:AppService,private _router:Router) { }

  ngOnInit() {

    this._leave.getLeave().subscribe(res => {
      this.data = res;
    });
  }

  displayedColumns = [
    "department",
    "employee",
    "type",
    "frdate",
    "todate",
    "reason",
    "status",
    "action"
  ];


  editLeave(roster){
    this._router.navigate(['leave/editLeave', roster.id]);
  }


  delete(permi) {
    this._leave.deleteLeave(permi.id).subscribe();
    //this.showToast();
  }

}
