import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'app/model/app.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-leave',
  templateUrl: './update-leave.component.html',
  styleUrls: ['./update-leave.component.scss']
})
export class UpdateLeaveComponent implements OnInit {
  data:{}
  depts:{}
  Id:string

  myform: FormGroup;
  states = [{ value: "active" }, { value: "inActive" }];
  types = [{ value: "Casual" }, { value: "earn" }, { value: "Medical" }];

  constructor(private fb: FormBuilder, private _leave: AppService, private toastr: ToastrService,private _route:ActivatedRoute) { }

  ngOnInit() {

    this._route.paramMap.subscribe(params => {
      this.Id = params.get("id");
      this.edit(this.Id);
    });

    this.myform = this.fb.group({
      department: [""],
      employee: [""],
      type: [""],
      frdate: [""],
      todate: [""],
      reason: [""],
      status: [""]
    });
    this._leave.getDept().subscribe(res => {
      this.depts = res;
    });
  }

  onChange(name: string) {
    this._leave.getEmpByDept(name).subscribe(res => {
      //this._eshift.emps = res as Employee[];
      this.data = res;
    });}

    edit(id) {
      this._leave.getLeaveId(id).subscribe((leave) => {
        this.setRoster(leave);
      });
    }
    setRoster(leave) {
      this.myform.patchValue({
        department: leave.department,
        employee: leave.employee,
        type: leave.type,
        frdate: leave.frdate,
        todate: leave.todate,
        reason: leave.reason,
        status: leave.status
      });
    }

    updateLeave() {
      this._leave.updateLeave(this.Id, this.myform.value).subscribe();
     // this.showToast();
    }

}
