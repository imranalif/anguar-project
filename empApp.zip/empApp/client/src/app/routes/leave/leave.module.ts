import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LeaveRoutingModule } from './leave-routing.module';
import { AddLeaveComponent } from './add-leave/add-leave.component';
import { ListLeaveComponent } from './list-leave/list-leave.component';
import { UpdateLeaveComponent } from './update-leave/update-leave.component';
import { MaterialModule } from '../material/material.module';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '@shared/shared.module';


@NgModule({
  declarations: [AddLeaveComponent, ListLeaveComponent, UpdateLeaveComponent],
  imports: [
    CommonModule,
    SharedModule,
    MaterialModule,
    ReactiveFormsModule,
    LeaveRoutingModule
  ]
})
export class LeaveModule { }
