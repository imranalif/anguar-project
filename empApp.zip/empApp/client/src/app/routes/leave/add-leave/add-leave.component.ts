import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'app/model/app.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-leave',
  templateUrl: './add-leave.component.html',
  styleUrls: ['./add-leave.component.scss']
})
export class AddLeaveComponent implements OnInit {
data:{}
  depts:{}

  myform: FormGroup;
  states = [{ value: "active" }, { value: "inActive" }];
  types = [{ value: "Casual" }, { value: "earn" }, { value: "Medical" }];

  constructor(private fb: FormBuilder, private _leave: AppService, private toastr: ToastrService) { }

  ngOnInit() {
    this.myform = this.fb.group({
      department: [""],
      employee: [""],
      type: [""],
      frdate: [""],
      todate: [""],
      reason: [""],
      status: [""]
    });
    this._leave.getDept().subscribe(res => {
      this.depts = res;
    });
   
  }

  onChange(name: string) {
    this._leave.getEmpByDept(name).subscribe(res => {
      //this._eshift.emps = res as Employee[];
      this.data = res;
    });
  }
  addLeave(){
    this._leave.addLeave(this.myform.value).subscribe()
  }

}
