import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.scss']
})
export class ViewProfileComponent implements OnInit {
data2:{}
  constructor() { }

  ngOnInit() {
    const data1=localStorage.getItem("data");
    this.data2 = JSON.parse(data1);
  }

}
