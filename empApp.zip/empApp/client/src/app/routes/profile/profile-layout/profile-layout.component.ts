import { Component } from '@angular/core';

@Component({
  selector: 'app-profile-layout',
  templateUrl: './profile-layout.component.html',
})
export class ProfileLayoutComponent {
 data2:{}
  constructor() { }

  ngOnInit() {
    const data1=localStorage.getItem("data");
    this.data2 = JSON.parse(data1);
    console.log(this.data2)
  }
}
