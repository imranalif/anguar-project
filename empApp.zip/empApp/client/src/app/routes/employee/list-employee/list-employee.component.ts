import { Component, OnInit,ViewChild,ChangeDetectorRef } from '@angular/core';
import {PageEvent , MatTableDataSource, MatSort, MatPaginator } from "@angular/material";
import { AppService } from 'app/model/app.service';
import { ConvertService } from 'app/model/convert.service';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { Employee } from 'app/model/employee.model';
import { Router } from '@angular/router';
import * as jsPDF from "jspdf";
import "jspdf-autotable";
//declare var jsPDF: any;



@Component({
  selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.scss']
})
export class ListEmployeeComponent implements OnInit {
  myform: FormGroup;
  totalEmp=40
  empPerPage=10
  pageSizeOption=[5,10]
  currentPage=1

weightes = [{ value: "1" }, { value: "2" }, { value: "3" }, { value: "4" }];
  data:{}
  emps: Employee[];
  dataSource = new MatTableDataSource();
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  constructor( private fb: FormBuilder,private _emp: AppService,private _router:Router,private _convert: ConvertService) { }

  ngOnInit() {
    this.myform = this.fb.group({ currentPage: [""]})

    this._emp.getEmployee(this.currentPage).subscribe(
      
      res =>{ this.dataSource = new MatTableDataSource(<any>res)}
      //this._emp.emps = res as Employee[];
    );

    
    setTimeout(() => (this.dataSource.sort = this.sort));
    setTimeout(() => (this.dataSource.paginator = this.paginator));
  }

  displayedColumns = [
    "firstName",
    "lastName",
    "employeeId",
    "email",
    "mobile",
    "address",
    "gender",
    "degination",
    "department",
    "role",
    "image",
    "status",
    "action"
  ];

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  editEmp(emp){
    this._router.navigate(['employee/editEmp', emp.id]);
  }
  convertPdf(){
   
    var doc =new jsPDF();
    
    (doc as any).autoTable({
      head:[['firstName','lastName','email']],
      html: "#table",
      theme: "grid",
      styles: {
        overflow: "visible",
        cellWidth: 15,
        minCellWidth: 10,
       
       
      },
      columnStyles:{
        columnName13: {
          columnWidth: 0
      },
      },
      headStyles: {
        cellWidth: 10,
        minCellWidth: 10
      },
      didDrawCell: data => {
        console.log(data.column.index);
      }
    });

    doc.save(".pdf");
  }

  convertCsv() {
    return this._convert.downloadFile(this._emp.emps);
    
  }

  onChange(currentPage){

this._emp.getEmployee(currentPage).subscribe(
  res =>{ this.dataSource = new MatTableDataSource(<any>res)
});
  }

  

}
