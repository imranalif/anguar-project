import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppService } from 'app/model/app.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.scss']
})
export class UpdateEmployeeComponent implements OnInit {
  data1:{}
  data2:{}
  data3:{}
  Id:string
  myform: FormGroup;

  states = [{ value: "active" }, { value: "inActive" }];
  gend = [{ value: "male" }, { value: "female" }, { value: "others" }];
  constructor(private fb: FormBuilder, private _emp: AppService,private _route:ActivatedRoute) { }

  ngOnInit() {
    this._route.paramMap.subscribe(params => {
      this.Id = params.get("id");
      this.edit(this.Id);
    });

    this.myform = this.fb.group({
      firstName: [""],
      lastName: [""],
      employeeId: ["", [Validators.required, Validators.minLength(5)]],
      mobile: [""],
      email: ["", [Validators.required, Validators.email]],
      address: [""],
      department: [""],
      degination: [""],
      role: [""],
      gender: [""],
      image: [""],
      password: ["", [Validators.required, Validators.minLength(5)]],
      status: [""]
    });

    this._emp.getDept().subscribe(res => (this.data1 = res));
    this._emp.getDegi().subscribe(res => (this.data2 = res));
    this._emp.getRole().subscribe(res => (this.data3 = res));
  }


  edit(id) {
    this._emp.getEmpId(id).subscribe((emp) => {
      this.setRoster(emp);
    });
  }
  setRoster(emp) {
    this.myform.patchValue({
      firstName: emp.firstName,
      lastName: emp.lastName,
      employeeId: emp.employeeId,
      mobile: emp.mobile,
      email: emp.email,
      address: emp.address,
      department: emp.department,
      degination: emp.degination,
      role: emp.role,
      gender: emp.gender,
      password: emp.password,
      addrstatusess: emp.status
    });
  }

  updateEmp() {
    this._emp.updateEmp(this.Id, this.myform.value).subscribe();
   // this.showToast();
  }

}
