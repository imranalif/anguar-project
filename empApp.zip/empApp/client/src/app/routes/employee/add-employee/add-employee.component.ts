import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppService } from 'app/model/app.service';
import { ToastrService } from 'ngx-toastr';

import {  FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';

//const URL = 'http://localhost:3000/api/addEmployee';


fileUpload: File = null;

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.scss']
})
export class AddEmployeeComponent implements OnInit {
  data1:{}
  data2:{}
  data3:{}

  uploadResponse = { status: '', message: '', filePath: '' };
  error: string;
  myform: FormGroup;

  states = [{ value: "active" }, { value: "inActive" }];
  gend = [{ value: "male" }, { value: "female" }, { value: "others" }];

  imgurl: string=null
  fileUpload: File = null;
  selectedFile: null;

  //public uploader: FileUploader = new FileUploader({ url: URL, itemAlias: 'image' });
  list:any=[]
images
  constructor(private fb: FormBuilder, private _emp: AppService, private toastr: ToastrService) { }

  ngOnInit() {

    




    this.myform = this.fb.group({
      firstName: [""],
      lastName: [""],
      employeeId: ["", [Validators.required, Validators.minLength(5)]],
      mobile: [""],
      email: ["", [Validators.required, Validators.email]],
      address: [""],
      department: [""],
      degination: [""],
      role: [""],
      gender: [""],
      image: [""],
      password: ["", [Validators.required, Validators.minLength(5)]],
      status: [""]
    });

    this._emp.getDept().subscribe(res => (this.data1 = res));
    this._emp.getDegi().subscribe(res => (this.data2 = res));
    this._emp.getRole().subscribe(res => (this.data3 = res));
    
  }

  onFileSelected(event) {
      if(event.target.files.length>0)
      {
        const image=event.target.files[0]
        this.images=image

        var reader = new FileReader();
    reader.onload = (event: any) => {
      this.imgurl = event.target.result;
    };
    reader.readAsDataURL(this.images);
      }
    }




  addEmp() {
    const formData=new FormData()
    formData.append('image',this.images)
    formData.append('firstName',this.myform.get('firstName').value)
    formData.append('lastName',this.myform.get('lastName').value)
    formData.append('employeeId',this.myform.get('employeeId').value)
    formData.append('mobile',this.myform.get('mobile').value)
    formData.append('email',this.myform.get('email').value)
    formData.append('address',this.myform.get('address').value)
    formData.append('department',this.myform.get('department').value)
    formData.append('degination',this.myform.get('degination').value)
    formData.append('role',this.myform.get('role').value)
    formData.append('gender',this.myform.get('gender').value)
    formData.append('password',this.myform.get('password').value)
    formData.append('status',this.myform.get('status').value)
    //console.log(myform.firstName)
    //this._emp.addEmp(this.myform.value,formData).subscribe();
    this._emp.addEmp(formData).subscribe(  (res) => this.uploadResponse = res,
    (err) => this.error = err);
    console.log(this.myform.value)
    this.showToast();
  }
  showToast() {
    this.toastr.success(JSON.stringify("Add successful"));
  }

 

}
