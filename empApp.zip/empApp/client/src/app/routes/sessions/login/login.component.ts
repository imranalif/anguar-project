import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AppService } from 'app/model/app.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
})
export class LoginComponent implements OnInit {
  reactiveForm: FormGroup;
  data:any[]

  constructor(private fb: FormBuilder, private _router: Router,private _login:AppService) {
    this.reactiveForm = this.fb.group({
      employeeId: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });
  }

  ngOnInit() {}

  login() {
    this._login.loginEmp(this.reactiveForm.value).subscribe(
      
      res => {
        //console.log(res);

        localStorage.setItem("token", res.token);
        localStorage.setItem("data", JSON.stringify(res.data));
        this._router.navigate(["/"]);
      },
      err =>{
        alert("something going  wrong");
         console.log(err)}
    );
    console.log(this.reactiveForm.value)
  }
}
