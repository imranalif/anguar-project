import { Component, OnInit } from '@angular/core';
import { AppService } from 'app/model/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-roster',
  templateUrl: './list-roster.component.html',
  styleUrls: ['./list-roster.component.scss']
})
export class ListRosterComponent implements OnInit {
data:{}
  constructor(private _roster: AppService,private _router:Router) { }

  ngOnInit() {
    this._roster.getEmpRoster().subscribe(res => {
      this.data = res;
    });
  }

  displayedColumns = [
    "department",
    "employee",
    "shift",
    "frdate",
    "todate",
    "status",
    "action"
  ]

  editRoster(roster){
    this._router.navigate(['roster/editRoster', roster.id]);
  }

}
