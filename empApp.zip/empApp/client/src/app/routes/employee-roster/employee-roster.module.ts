import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeeRosterRoutingModule } from './employee-roster-routing.module';
import { AddRosterComponent } from './add-roster/add-roster.component';
import { ListRosterComponent } from './list-roster/list-roster.component';
import { UpdateRosterComponent } from './update-roster/update-roster.component';
import { SharedModule } from '@shared/shared.module';
import { MaterialModule } from '../material/material.module';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [AddRosterComponent, ListRosterComponent, UpdateRosterComponent],
  imports: [
    CommonModule,
    SharedModule,
    MaterialModule,
    ReactiveFormsModule,
    EmployeeRosterRoutingModule
  ]
})
export class EmployeeRosterModule { }
