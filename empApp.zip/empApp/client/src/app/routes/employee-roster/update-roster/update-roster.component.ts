import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppService } from 'app/model/app.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Roster } from 'app/model/roster.model';

@Component({
  selector: 'app-update-roster',
  templateUrl: './update-roster.component.html',
  styleUrls: ['./update-roster.component.scss']
})
export class UpdateRosterComponent implements OnInit {
  myform: FormGroup;
  data:{}
  data1: {};
  data2: {};
  Id:string

  states = [{ value: "active" }, { value: "inActive" }];

  constructor(private fb: FormBuilder, private _roster: AppService, private _router: Router,
    private _route: ActivatedRoute) { }

  ngOnInit() {

    this._route.paramMap.subscribe(params => {
      this.Id = params.get("id");
      this.edit(this.Id);
    });

    this.myform = this.fb.group({
      department: [""],
      employee: [""],
      shift: [""],
      frdate: [""],
      todate: [""],
      status: [""]
    });
    this._roster.getDept().subscribe(res => {
      this.data1 = res ;
    });
    this._roster.getShift().subscribe(res => {
      this.data2 = res ;
    });
  }

  onChange(name: string) {
    this._roster.getEmpByDept(name).subscribe(res => {
      //this._eshift.emps = res as Employee[];
      this.data = res;
    });
  }


  edit(id) {
    this._roster.getRosterId(id).subscribe((roster: Roster) => {
      this.setRoster(roster);
    });
  }
  setRoster(roster: Roster) {
    this.myform.patchValue({
      department: roster.department,
      employee: roster.employee,
      shift: roster.shift,
      frdate: roster.frdate,
      todate: roster.todate,
      status: roster.status
    });
  }

  updateRoster() {
    this._roster.updateRoster(this.Id, this.myform.value).subscribe();
   // this.showToast();
  }

}
