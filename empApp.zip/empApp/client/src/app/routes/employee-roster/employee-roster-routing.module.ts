import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddRosterComponent } from './add-roster/add-roster.component';
import { ListRosterComponent } from './list-roster/list-roster.component';
import { UpdateRosterComponent } from './update-roster/update-roster.component';


const routes: Routes = [ { path: 'addRoster', component: AddRosterComponent },
{ path: 'listRoster', component: ListRosterComponent },
{ path: 'editRoster/:id', component: UpdateRosterComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmployeeRosterRoutingModule { }
