import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppService } from 'app/model/app.service';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-add-roster',
  templateUrl: './add-roster.component.html',
  styleUrls: ['./add-roster.component.scss']
})
export class AddRosterComponent implements OnInit {
  myform: FormGroup;
  data:{}
  data1: {};
  data2: {};

  states = [{ value: "active" }, { value: "inActive" }];

  constructor(private fb: FormBuilder, private _roster: AppService, private toastr: ToastrService) { }

  ngOnInit() {
    this.myform = this.fb.group({
      department: [""],
      employee: [""],
      shift: [""],
      frdate: [""],
      todate: [""],
      status: [""]
    });
    this._roster.getDept().subscribe(res => {
      this.data1 = res ;
    });
    this._roster.getShift().subscribe(res => {
      this.data2 = res ;
    });

  }

  onChange(name: string) {
    this._roster.getEmpByDept(name).subscribe(res => {
      //this._eshift.emps = res as Employee[];
      this.data = res;
    });
  }

  addRoster(){
    this._roster.addRoster(this.myform.value).subscribe()
  }


}
