import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'app/model/app.service';

@Component({
  selector: 'app-add-group',
  templateUrl: './add-group.component.html',
  styleUrls: ['./add-group.component.scss']
})
export class AddGroupComponent implements OnInit {
  myform: FormGroup;
  states = [{ value: "active" }, { value: "inActive" }];

  constructor(private fb: FormBuilder, private _group: AppService) { }

  ngOnInit() {
    this.myform = this.fb.group({
      name: [''],
      description: [''],
      status: [''],
    });
  }

  addGroup(){
    this._group.addGroup(this.myform.value).subscribe()
  }

}
