import { Component, OnInit } from '@angular/core';
import { AppService } from 'app/model/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-group',
  templateUrl: './list-group.component.html',
  styleUrls: ['./list-group.component.scss']
})
export class ListGroupComponent implements OnInit {
  data:{}

  constructor(private _group: AppService,private _router:Router) { }

  ngOnInit() {
    this._group.getGroup().subscribe(res=>{this.data=res})

  }
  displayedColumns = ['id', 'name', 'status', 'action'];


  editPermi(permi){
    this._router.navigate(['group/editGroup', permi.id]);
  }

  delete(group) {
    this._group.deletePermi(group.id).subscribe();
    //this.showToast();
  }
}
