import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'app/model/app.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-group',
  templateUrl: './update-group.component.html',
  styleUrls: ['./update-group.component.scss']
})
export class UpdateGroupComponent implements OnInit {
  Id:string
  myform: FormGroup;
  states = [{ value: "active" }, { value: "inActive" }];

  constructor(private fb: FormBuilder, private _group: AppService,private _route: ActivatedRoute) { }

  ngOnInit() {
    this._route.paramMap.subscribe(params => {
      this.Id = params.get("id");
      this.edit(this.Id);
    });
    this.myform = this.fb.group({
      name: [''],
      description: [''],
      status: [''],
    });

  }
  edit(id) {
    this._group.getGroupId(id).subscribe(group=> {
      this.setPermi(group);
    });
  }
  setPermi(group) {
    this.myform.patchValue({
      name: group.name,
      
      status: group.status
    });
  }

  updateGroup() {
    this._group.updateGroup(this.Id, this.myform.value).subscribe();
   // this.showToast();
  }

}
