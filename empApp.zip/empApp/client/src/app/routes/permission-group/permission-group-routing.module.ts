import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddGroupComponent } from './add-group/add-group.component';
import { ListGroupComponent } from './list-group/list-group.component';
import { UpdateGroupComponent } from './update-group/update-group.component';


const routes: Routes = [{ path: 'addGro', component: AddGroupComponent },
{ path: 'listGroup', component: ListGroupComponent },
{ path: 'editGroup/:id', component: UpdateGroupComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PermissionGroupRoutingModule { }
