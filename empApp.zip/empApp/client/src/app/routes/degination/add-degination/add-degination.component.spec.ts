import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDeginationComponent } from './add-degination.component';

describe('AddDeginationComponent', () => {
  let component: AddDeginationComponent;
  let fixture: ComponentFixture<AddDeginationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddDeginationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDeginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
