import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'app/model/app.service';

@Component({
  selector: 'app-add-degination',
  templateUrl: './add-degination.component.html',
  styleUrls: ['./add-degination.component.scss'],
})
export class AddDeginationComponent implements OnInit {
  myform: FormGroup;
  states = [{ value: 'active' }, { value: 'inActive' }];

  constructor(private fb: FormBuilder, private _degi: AppService) {}

  ngOnInit() {
    this.myform = this.fb.group({
      name: [''],
      description: [''],
      status: [''],
    });
  }

  addDegi() {
    console.log(this.myform.value);
    this._degi.addDegi(this.myform.value).subscribe();
  }
}
