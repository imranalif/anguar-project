import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDeginationComponent } from './update-degination.component';

describe('UpdateDeginationComponent', () => {
  let component: UpdateDeginationComponent;
  let fixture: ComponentFixture<UpdateDeginationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateDeginationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDeginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
