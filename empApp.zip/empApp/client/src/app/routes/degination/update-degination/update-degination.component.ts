import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'app/model/app.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Degination } from 'app/model/degination.model';

@Component({
  selector: 'app-update-degination',
  templateUrl: './update-degination.component.html',
  styleUrls: ['./update-degination.component.scss'],
})
export class UpdateDeginationComponent implements OnInit {
  myform: FormGroup;
  Id: string;
  states = [{ value: 'active' }, { value: 'inActive' }];

  constructor(
    private _degi: AppService,
    private _route: ActivatedRoute,
    private fb: FormBuilder,
    private _router: Router
  ) {}

  ngOnInit() {
    this.myform = this.fb.group({
      name: [''],
      description: [''],
      status: [''],
    });

    this._route.paramMap.subscribe(params => {
      this.Id = params.get('id');
      this.edit(this.Id);
    });
  }
  edit(id) {
    this._degi.getDegiId(id).subscribe(dept => {
      console.log(dept);
      this.setDept(dept);
    });
  }
  setDept(dept) {
    console.log(dept); //[0]  added
    this.myform.patchValue({
      name: dept.name,
      description: dept.description,
      status: dept.status,
    });
  }

  updateDegi() {
    this._degi.updateDegi(this.Id, this.myform.value).subscribe();
    //this.showToast();
  }
}
