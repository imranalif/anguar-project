import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListDeginationComponent } from './list-degination.component';

describe('ListDeginationComponent', () => {
  let component: ListDeginationComponent;
  let fixture: ComponentFixture<ListDeginationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListDeginationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListDeginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
