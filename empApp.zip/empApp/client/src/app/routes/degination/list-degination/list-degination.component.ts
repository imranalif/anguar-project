import { Component, OnInit } from '@angular/core';
import { AppService } from 'app/model/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-degination',
  templateUrl: './list-degination.component.html',
  styleUrls: ['./list-degination.component.scss'],
})
export class ListDeginationComponent implements OnInit {
  data: {};

  constructor(private _degi: AppService, private _router: Router) {}

  ngOnInit() {
    this._degi.getDegi().subscribe(res => (this.data = res));
    console.log(this.data);
  }

  displayedColumns = ['id', 'name', 'description', 'status', 'action'];

  editDegi(degi) {
    this._router.navigate(['degination/editDegi', degi.id]); //for mongo dept._id
  }
}
