import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DeginationRoutingModule } from './degination-routing.module';
import { AddDeginationComponent } from './add-degination/add-degination.component';
import { ListDeginationComponent } from './list-degination/list-degination.component';
import { UpdateDeginationComponent } from './update-degination/update-degination.component';
import { SharedModule } from '@shared/shared.module';

@NgModule({
  declarations: [AddDeginationComponent, ListDeginationComponent, UpdateDeginationComponent],
  imports: [CommonModule, SharedModule, DeginationRoutingModule],
})
export class DeginationModule {}
