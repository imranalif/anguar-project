import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddDeginationComponent } from './add-degination/add-degination.component';
import { ListDeginationComponent } from './list-degination/list-degination.component';
import { UpdateDeginationComponent } from './update-degination/update-degination.component';

const routes: Routes = [
  { path: 'add', component: AddDeginationComponent },
  { path: 'listDegi', component: ListDeginationComponent },
  { path: 'editDegi/:id', component: UpdateDeginationComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DeginationRoutingModule {}
