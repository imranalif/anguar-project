import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddOffdayComponent } from './add-offday/add-offday.component';
import { ListOffdayComponent } from './list-offday/list-offday.component';
import { UpdateOffdayComponent } from './update-offday/update-offday.component';


const routes: Routes = [{ path: 'addOffday', component: AddOffdayComponent },
{ path: 'listOffday', component: ListOffdayComponent },
{ path: 'editOffday/:id', component: UpdateOffdayComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OffdayRoutingModule { }
