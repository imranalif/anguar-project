import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppService } from 'app/model/app.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-offday',
  templateUrl: './add-offday.component.html',
  styleUrls: ['./add-offday.component.scss']
})
export class AddOffdayComponent implements OnInit {
  myform: FormGroup;

  states = [{ value: "active" }, { value: "inActive" }];
  days = [
    { value: "Weekend" },
    { value: "Government" },
    { value: "Casual" },
    { value: "Annual" },
    { value: "Others" }
  ];

  constructor(private fb: FormBuilder, private _offday: AppService, private toastr: ToastrService) { }

  ngOnInit() {
    this.myform = this.fb.group({
      title: [""],
      type: [""],
      date: [""],
      status: [""]
    });
  }

  addOffDay() {
    this._offday.addOffDay(this.myform.value).subscribe();
    console.log(this.myform.value);
  }

}
