import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOffdayComponent } from './add-offday.component';

describe('AddOffdayComponent', () => {
  let component: AddOffdayComponent;
  let fixture: ComponentFixture<AddOffdayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddOffdayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOffdayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
