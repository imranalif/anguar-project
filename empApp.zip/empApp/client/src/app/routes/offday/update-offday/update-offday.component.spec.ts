import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateOffdayComponent } from './update-offday.component';

describe('UpdateOffdayComponent', () => {
  let component: UpdateOffdayComponent;
  let fixture: ComponentFixture<UpdateOffdayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateOffdayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateOffdayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
