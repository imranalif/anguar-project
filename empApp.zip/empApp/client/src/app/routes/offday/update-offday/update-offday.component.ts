import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppService } from 'app/model/app.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-offday',
  templateUrl: './update-offday.component.html',
  styleUrls: ['./update-offday.component.scss']
})
export class UpdateOffdayComponent implements OnInit {
  myform: FormGroup;
  Id:string

  states = [{ value: "active" }, { value: "inActive" }];
  days = [
    { value: "Weekend" },
    { value: "Government" },
    { value: "Casual" },
    { value: "Annual" },
    { value: "Others" }
  ];

  constructor(private fb: FormBuilder, private _offday: AppService,private _route:ActivatedRoute) { }

  ngOnInit() {
    this._route.paramMap.subscribe(params => {
      this.Id = params.get("id");
      this.edit(this.Id);
    });

    this.myform = this.fb.group({
      title: [""],
      type: [""],
      date: [""],
      status: [""]
    });
  }
  edit(id) {
    this._offday.getOffdayId(id).subscribe((offday) => {
      this.setPermi(offday);
    });
  }
  setPermi(offday) {
    this.myform.patchValue({
      title: offday.title,
      type: offday.type,
      date: offday.date,
      status: offday.status
    });
  }

}
