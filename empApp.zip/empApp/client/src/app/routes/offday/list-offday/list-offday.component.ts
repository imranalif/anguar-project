import { Component, OnInit } from '@angular/core';
import { AppService } from 'app/model/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-offday',
  templateUrl: './list-offday.component.html',
  styleUrls: ['./list-offday.component.scss']
})
export class ListOffdayComponent implements OnInit {
  data:{}

  constructor(private _offday: AppService,private _router:Router) { }

  ngOnInit() {

    this._offday.getOffDay().subscribe(res => {
      this.data = res;
    });
  }

  displayedColumns = ["title", "type", "date", "status", "action"];

  editOffday(permi){
    this._router.navigate(['offday/editOffday', permi.id]);
  }
}
