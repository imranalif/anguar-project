import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListOffdayComponent } from './list-offday.component';

describe('ListOffdayComponent', () => {
  let component: ListOffdayComponent;
  let fixture: ComponentFixture<ListOffdayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListOffdayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListOffdayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
