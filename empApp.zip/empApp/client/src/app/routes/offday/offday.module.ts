import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OffdayRoutingModule } from './offday-routing.module';
import { AddOffdayComponent } from './add-offday/add-offday.component';
import { ListOffdayComponent } from './list-offday/list-offday.component';
import { UpdateOffdayComponent } from './update-offday/update-offday.component';
import { SharedModule } from '@shared/shared.module';
import { MaterialModule } from '../material/material.module';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [AddOffdayComponent, ListOffdayComponent, UpdateOffdayComponent],
  imports: [
    CommonModule,
    SharedModule,
    MaterialModule,
    ReactiveFormsModule,
    OffdayRoutingModule
  ]
})
export class OffdayModule { }
