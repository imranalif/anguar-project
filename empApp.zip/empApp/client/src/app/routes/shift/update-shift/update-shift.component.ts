import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppService } from 'app/model/app.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-shift',
  templateUrl: './update-shift.component.html',
  styleUrls: ['./update-shift.component.scss']
})
export class UpdateShiftComponent implements OnInit {
  myform: FormGroup;
  states = [{ value: "active" }, { value: "inActive" }];
  Id:string

  constructor(private fb: FormBuilder, private _shift: AppService,private _route:ActivatedRoute) { }

  ngOnInit() {
    this.myform = this.fb.group({
      name: [""],
      description: [""],
      start: [""],
      end: [""],
      logout: [""],
      grace: [""],
      status: [""]
    });

    this._route.paramMap.subscribe(params => {
      this.Id = params.get("id");
      this.edit(this.Id);
    });
  }
  edit(id) {
    this._shift.getShiftId(id).subscribe((shift) => {
      this.setDept(shift);
    });
  }
  setDept(shift) {
    //console.log(role[0]); //[0]  added
    this.myform.patchValue({
      name: shift.name,
      description: shift.description,
      start: shift.start,
      end: shift.end,
      logout: shift.logout,
      grace: shift.grace,
      status: shift.status
    });
  }

  updateShift() {
    this._shift.updateShift(this.Id, this.myform.value).subscribe();
    //console.log(this.myform.value);
    //this._router.navigate(["role/listRole"]);
  }

}
