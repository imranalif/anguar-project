import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@shared/shared.module';

import { ShiftRoutingModule } from './shift-routing.module';
import { AddShiftComponent } from './add-shift/add-shift.component';
import { ListShiftComponent } from './list-shift/list-shift.component';
import { UpdateShiftComponent } from './update-shift/update-shift.component';
import { MaterialModule } from '../material/material.module';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [AddShiftComponent, ListShiftComponent, UpdateShiftComponent],
  imports: [
    CommonModule,
    SharedModule,
    MaterialModule,
    ReactiveFormsModule,
    ShiftRoutingModule
  ]
})
export class ShiftModule { }
