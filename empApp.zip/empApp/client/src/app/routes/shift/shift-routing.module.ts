import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddShiftComponent } from './add-shift/add-shift.component';
import { ListShiftComponent } from './list-shift/list-shift.component';
import { UpdateShiftComponent } from './update-shift/update-shift.component';


const routes: Routes = [ { path: 'addShift', component: AddShiftComponent },
{ path: 'listShift', component: ListShiftComponent },
{ path: 'editShift/:id', component: UpdateShiftComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ShiftRoutingModule { }
