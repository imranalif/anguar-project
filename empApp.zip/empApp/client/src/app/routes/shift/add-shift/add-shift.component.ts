import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppService } from 'app/model/app.service';

@Component({
  selector: 'app-add-shift',
  templateUrl: './add-shift.component.html',
  styleUrls: ['./add-shift.component.scss']
})
export class AddShiftComponent implements OnInit {
  myform: FormGroup;
  states = [{ value: "active" }, { value: "inActive" }];

  constructor(private fb: FormBuilder, private _shift: AppService) { }

  ngOnInit() {
    this.myform = this.fb.group({
      name: [""],
      description: [""],
      start: [""],
      end: [""],
      logout: [""],
      grace: [""],
      status: [""]
    });
  }
  addShift() {
    this._shift.addShift(this.myform.value).subscribe();}

}
