import { Component, OnInit } from '@angular/core';
import { AppService } from 'app/model/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-shift',
  templateUrl: './list-shift.component.html',
  styleUrls: ['./list-shift.component.scss']
})
export class ListShiftComponent implements OnInit {
  data:{}
  constructor(private _shift:AppService,private _router:Router) { }

  ngOnInit() {
    this._shift.getShift().subscribe(res=>this.data=res)
  }

  displayedColumns = ["name", "description","start","end","grace","logout", "status","action"];

  editShift(role) {
    this._router.navigate(['shift/editShift', role.id]); 
  }
  delete(group) {
    this._shift.deleteShift(group.id).subscribe();
    //this.showToast();
  }
}
