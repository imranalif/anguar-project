import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PermissionRoutingModule } from './permission-routing.module';
import { AddPermissionComponent } from './add-permission/add-permission.component';
import { ListPermissionComponent } from './list-permission/list-permission.component';
import { UpdatePermissionComponent } from './update-permission/update-permission.component';
import { SharedModule } from '@shared/shared.module';
import { MaterialModule } from '../material/material.module';
import { ReactiveFormsModule } from '@angular/forms';
import { CheckPermissionComponent } from './check-permission/check-permission.component';


@NgModule({
  declarations: [AddPermissionComponent, ListPermissionComponent, UpdatePermissionComponent, CheckPermissionComponent],
  imports: [
    CommonModule,
    SharedModule,
    MaterialModule,
    ReactiveFormsModule,
    PermissionRoutingModule
  ]
})
export class PermissionModule { }
