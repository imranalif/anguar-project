import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppService } from 'app/model/app.service';
import { UniqueItemValidator } from 'app/model/unique-item.directive';

@Component({
  selector: 'app-add-permission',
  templateUrl: './add-permission.component.html',
  styleUrls: ['./add-permission.component.scss']
})
export class AddPermissionComponent implements OnInit {
  myform: FormGroup;
  states = [{ value: "active" }, { value: "inActive" }];

  weightes = [{ value: "1" }, { value: "2" }, { value: "3" }, { value: "4" }];

  data: {};

  constructor(private fb: FormBuilder, private _permi: AppService) { }

  ngOnInit() {
    this.myform = this.fb.group({
      gname: [""],
      //name: [""],
      item: ["",null,UniqueItemValidator(this._permi)],
      order: [""],
      status: [""]
    });
    this._permi.getGroup().subscribe(res=>{this.data=res})
  }

  addPermi(){
    this._permi.addPermi(this.myform.value).subscribe()
  }

}
