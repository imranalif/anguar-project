import { Component, OnInit } from '@angular/core';
import { AppService } from 'app/model/app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-permission',
  templateUrl: './list-permission.component.html',
  styleUrls: ['./list-permission.component.scss']
})
export class ListPermissionComponent implements OnInit {

  data:{}
  constructor(private _permi: AppService,private _router:Router) { }

  ngOnInit() {
    this._permi.getPermi().subscribe(res=>{this.data=res})
  }

  displayedColumns = ['id', 'gname','item','order', 'status', 'action'];

  editPermi(permi){
    this._router.navigate(['permission/editPermi', permi.id]);
  }

  delete(permi) {
    this._permi.deletePermi(permi.id).subscribe();
    //this.showToast();
  }
}
