import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddPermissionComponent } from './add-permission/add-permission.component';
import { ListPermissionComponent } from './list-permission/list-permission.component';
import { UpdatePermissionComponent } from './update-permission/update-permission.component';
import { CheckPermissionComponent } from './check-permission/check-permission.component';


const routes: Routes = [{ path: 'addPermi', component: AddPermissionComponent },
{ path: 'listPermi', component: ListPermissionComponent },
{ path: 'checkPermi', component: CheckPermissionComponent },
{ path: 'editPermi/:id', component: UpdatePermissionComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PermissionRoutingModule { }
