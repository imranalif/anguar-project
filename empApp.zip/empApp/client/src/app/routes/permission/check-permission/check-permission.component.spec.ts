import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckPermissionComponent } from './check-permission.component';

describe('CheckPermissionComponent', () => {
  let component: CheckPermissionComponent;
  let fixture: ComponentFixture<CheckPermissionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckPermissionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckPermissionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
