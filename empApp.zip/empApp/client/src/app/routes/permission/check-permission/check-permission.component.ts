import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray } from "@angular/forms";
import { AppService } from 'app/model/app.service';
import { FormsModule } from '@angular/forms';
import { Group } from 'app/model/group.model';


@Component({
  selector: 'app-check-permission',
  templateUrl: './check-permission.component.html',
  styleUrls: ['./check-permission.component.scss']
})
export class CheckPermissionComponent implements OnInit {
groups:Group[]=[]
data:any[]=[]
element:[]
data1:any
data2=new FormArray([])
myform: FormGroup;
gname:false

constructor(private fb: FormBuilder, private _permi: AppService) { }

  ngOnInit() {
    this.myform = this.fb.group({
      gname: [""],
      //name: [""],
      item: [""],
     
    });
    this._permi.getGroup().subscribe(res=>{this.data.push(res)
      // for (let i = 1; i <= 100; i++) {
      //   this.data.push(res);
      //   } ;
      this._permi.getPermiItem(this.data[0].name).subscribe(res=>{this.data1=res})
console.log(this.data[0].name)
      // this.data[0].forEach(element => {
      //   this._permi.getPermiItem(element).subscribe(res=>{this.data1=res
      //     this.data1.forEach(ref=>{
      //       console.log(ref)
      //     })
      //   })
      //   console.log(element)
      // });
     },
     
      )
      
   
      //this._permi.getPermi().subscribe(res=>{this.data1=res})
  }
  
  
}
