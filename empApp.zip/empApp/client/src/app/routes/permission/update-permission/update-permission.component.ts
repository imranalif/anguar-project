import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AppService } from 'app/model/app.service';
import { UniqueItemValidator } from 'app/model/unique-item.directive';
import { ActivatedRoute } from '@angular/router';
import { Permission } from 'app/model/permission.model';

@Component({
  selector: 'app-update-permission',
  templateUrl: './update-permission.component.html',
  styleUrls: ['./update-permission.component.scss']
})
export class UpdatePermissionComponent implements OnInit {

  myform: FormGroup;
  states = [{ value: "active" }, { value: "inActive" }];

  weightes = [{ value: "1" }, { value: "2" }, { value: "3" }, { value: "4" }];
  data:{}
  Id:string
  constructor(private fb: FormBuilder, private _permi: AppService,private _route: ActivatedRoute) { }

  ngOnInit() {
    this._route.paramMap.subscribe(params => {
      this.Id = params.get("id");
      this.edit(this.Id);
    });

    this.myform = this.fb.group({
      gname: [""],
      //name: [""],
      item: ["",null,UniqueItemValidator(this._permi)],
      order: [""],
      status: [""]
    });
    this._permi.getGroup().subscribe(res=>{this.data=res})
  
  }
  edit(id) {
    this._permi.getPermiId(id).subscribe((permi: Permission) => {
      this.setPermi(permi);
    });
  }
  setPermi(permi: Permission) {
    this.myform.patchValue({
      gname: permi.gname,
      item: permi.item,
      order: permi.order,
      status: permi.status
    });
  }

  updatePermi() {
    this._permi.updatePermi(this.Id, this.myform.value).subscribe();
   // this.showToast();
  }

}
