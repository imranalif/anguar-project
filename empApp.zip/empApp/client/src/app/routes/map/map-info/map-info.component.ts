import { Component, OnInit } from '@angular/core';

import "leaflet";

import 'leaflet-polylinedecorator';
import "leaflet-draw";
//import "leaflet.motion";
import "../../../../../node_modules/leaflet.motion/dist/leaflet.motion.min.js";
//import "../../../../../node_modules/leaflet-polylineDecorator/dist/leaflet.polylineDecorator.js";
declare let L;

@Component({
  selector: 'app-map-info',
  templateUrl: './map-info.component.html',
  styleUrls: ['./map-info.component.scss']
})
export class MapInfoComponent implements OnInit {
  title = "map";
  constructor() { }

  ngOnInit() {

    const map = L.map("mapid").setView([51.505, -0.09], 13);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution:
        '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    /*

    var options = {
      draw: {
        circle: false, // Turns off this drawing tool
        rectangle: false,
        marker: false,
        circlemarker: false
      }
    };

    var drawControl = new L.Control.Draw(options);
    map.addControl(drawControl);

    map.on(L.Draw.Event.CREATED, function(e) {
      var type = e.layerType,
        layer = e.layer;

      if (type === "polyline") {
        var line = L.motion
          .polyline(
            layer.getLatLngs(),
            {
              color: "orange"
            },
            {
              auto: true,
              easing: L.Motion.Ease.swing
            }
          )
          .motionSpeed(100000)
          .addTo(map);
      }
    });*/

    // var carRoute = JSON.parse(
    //   '[{"lat":51.510986,"lng":-0.100079},{"lat":51.486621,"lng":-0.092354},]'
    // );
    var marker = L.marker([51.510986, -0.100079])
    .bindTooltip("Jigatola", { permanent: true })
    .addTo(map);

    var marker = L.marker([51.486621, -0.092354])
    .bindTooltip("Mirpur", { permanent: true })
    .addTo(map);


    var polyline = L.motion
      .polyline(
        [
          [51.510986, -0.100079],
          [51.51558, -0.075016],
          [51.513657, -0.034676],
          [51.502545, -0.021973],
          [51.491858, -0.025406],
          [51.488652, -0.048065],
          [51.495172, -0.062656],
          [51.486621, -0.092354]
        ],
        {
          color: "red"
        },
        {
          auto: true,
          duration: 3000,
          easing: L.Motion.Ease.easeInOutQuart
        },
        {
          removeOnEnd: true,
          //showMarker: true,
          icon: L.divIcon({
            html: "<i class='fa fa-car fa-2x' aria-hidden='true'></i>",
            iconSize: L.point(27.5, 24)
          })
        }
      )
      .addTo(map);

    // seqGroup.on("click", function(){
    //   seqGroup.motionStart();
    // });

    /*
    var marker = L.marker([51.510986, -0.100079])
      .bindTooltip("Jigatola", { permanent: true })
      .addTo(map);
    // marker.bindPopup("You clicked the map at " + marker.latlng).openPopup();

    var marker = L.marker([51.506712, -0.069866])
      .bindTooltip("Dhanmondi", { permanent: true })
      .addTo(map);
    // marker.bindPopup("<b>Hello world!</b><br>I am a popup2.").openPopup();

    var marker = L.marker([51.49421, -0.071583]).addTo(map);
    marker.bindTooltip("Sankar", { permanent: true }).openPopup();

    var marker = L.marker([51.486621, -0.092354]).addTo(map);
    marker.bindTooltip("Mohammadpur", { permanent: true }).openPopup();
    // var polylinea = L.polyline([
    //   [51.510986, -0.100079],
    //   [51.506712, -0.069866],
    //   [51.49421, -0.071583],
    //   [51.486621, -0.092354]
    // ]).addTo(map);

    var polyline = L.motion
      .polyline(
        [
          [51.510986, -0.100079],
          [51.506712, -0.069866],
          [51.49421, -0.071583],
          [51.486621, -0.092354]
        ],
        {
          color: "transparent"
        },
        {
          auto: true,
          duration: 3000,
          easing: L.Motion.Ease.easeInOutQuart
        },
        {
          removeOnEnd: true,
          //showMarker: true,
          icon: L.divIcon({
            html: "<i class='fa fa-car fa-2x' aria-hidden='true'></i>",
            iconSize: L.point(27.5, 24)
          })
        }
      )
      .addTo(map);

    var arrow = L.polylineDecorator(polyline, {
      patterns: [
        {
          offset: 0,
          repeat: 60,
          symbol: L.Symbol.arrowHead({
            pixelSize: 15,
            pathOptions: { fillOpacity: 0.75, color: " shade", weight: 0 }
          })
        }
      ]
    }).addTo(map);

  }*/
    var popup = L.popup();

    function onMapClick(marker) {
      popup
        .setLatLng(marker.latlng)
        .setContent("You clicked the map at " + marker.latlng.toString())
        .openOn(map);
    }

    map.on("click", onMapClick);
  }

}
