import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'app/model/app.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Department } from 'app/model/department.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-update-department',
  templateUrl: './update-department.component.html',
  styleUrls: ['./update-department.component.scss'],
})
export class UpdateDepartmentComponent implements OnInit {
  myform: FormGroup;
  Id: string;
  states = [{ value: 'active' }, { value: 'inActive' }];

  constructor(
    private _dept: AppService,
    private _route: ActivatedRoute,
    private fb: FormBuilder,
    private _router: Router,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.myform = this.fb.group({
      name: [''],
      description: [''],
      status: [''],
    });

    this._route.paramMap.subscribe(params => {
      this.Id = params.get('id');
      this.edit(this.Id);
    });
  }

  edit(id) {
    this._dept.getDeptId(id).subscribe((dept: Department) => {
      this.setDept(dept);
    });
  }
  setDept(dept: Department) {
    console.log(dept); //[0]  added
    this.myform.patchValue({
      name: dept.name,
      description: dept.description,
      status: dept.status,
    });
  }
  updateDept() {
    this._dept.updateDept(this.Id, this.myform.value).subscribe();
    this.showToast();
  }
  showToast() {
    this.toastr.success(JSON.stringify('Updated successfully'));
  }
}
