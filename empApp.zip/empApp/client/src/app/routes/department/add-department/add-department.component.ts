import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'app/model/app.service';
import { ToastrService } from 'ngx-toastr';
import { UniqueItemValidator } from 'app/model/unique-item.directive';

@Component({
  selector: 'app-add-department',
  templateUrl: './add-department.component.html',
  styleUrls: ['./add-department.component.scss'],
})
export class AddDepartmentComponent implements OnInit {
  myform: FormGroup;
  states = [{ value: 'active' }, { value: 'inActive' }];

  model = { note: 'add successfully' };
  constructor(private fb: FormBuilder, private _dept: AppService, private toastr: ToastrService) {}

  ngOnInit() {
    this.myform = this.fb.group({
      name: [''],
      description: [''],
      status: [''],
    });
  }

  addDept() {
    this._dept.addDept(this.myform.value).subscribe();
    this.showToast();
  }
  showToast() {
    this.toastr.success(JSON.stringify(this.model));
  }
}
