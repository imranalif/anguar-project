import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReactiveFormsModule } from '@angular/forms';

import { DepartmentRoutingModule } from './department-routing.module';
import { AddDepartmentComponent } from './add-department/add-department.component';
import { ListDepartmentComponent } from './list-department/list-department.component';
import { UpdateDepartmentComponent } from './update-department/update-department.component';
import { MaterialModule } from '../material/material.module';
import { SharedModule } from '@shared/shared.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { ImportComponent } from './import/import.component';

@NgModule({
  declarations: [AddDepartmentComponent, ListDepartmentComponent, UpdateDepartmentComponent, ImportComponent],
  imports: [
    CommonModule,
    SharedModule,
    MaterialModule,
    ReactiveFormsModule,
    DepartmentRoutingModule,
    NgxPaginationModule,
  ],
})
export class DepartmentModule {}
