import { Component, OnInit ,ViewChild} from '@angular/core';
//import { Papa } from 'ngx-papaparse';
import * as Papa from 'papaparse';
import { CSVRecord } from 'app/model/csvrecord.model';


@Component({
  selector: 'app-import',
  templateUrl: './import.component.html',
  styleUrls: ['./import.component.scss']
})
export class ImportComponent implements OnInit {
  dataList : any=[];
  value:any
  headerRow: any[] = [];
  //records: any[] = [];
  constructor() { }
  public records: any[] = [];  
  @ViewChild('csvReader',{ static: false }) csvReader: any; 

  ngOnInit() {
  }


  displayedColumns = [
    "id",
    "uniqueID",
    "enterqueue",
    "connect",
    "caller",
    "hunting",
    "agent",
    "extension",
    "campaign",
    "ivr",
    "wait",
    "coTime",
    "rTime",
    "tTime",
    "rna",
    "transfer",
    "status",
    "cby",
    "cTime"
  ];


  uploadListener($event: any): void {  
    let text = [];  
    let files = $event.srcElement.files;  
    //console.log(files[0]);
    if (this.isValidCSVFile(files[0])) {  
      let input = $event.target;  
      let reader = new FileReader();  
      reader.readAsText(input.files[0]);  
      
      reader.onload = () => {  
        //console.log('You r here!!!');
        let csvData = reader.result;  
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);  
        console.log(csvRecordsArray);
  
        let headersRow = this.getHeaderArray(csvRecordsArray);  
        console.log(headersRow);
        this.records = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
        //console.log(this.records)  
      };  
  
      reader.onerror = function () {  
        console.log('error is occured while reading file!');  
      };  
  
    } else {  
      alert("Please import valid .csv file.");  
      this.fileReset();  
    }  
  }  
  
  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {  
    let csvArr = [];  
    //curruntRecord:String
    for (let i = 2; i < csvRecordsArray.length; i++) {  
      let curruntRecord = (<string>csvRecordsArray[i]).split(',');  
      if (curruntRecord.length == headerLength) {  
        let csvRecord: CSVRecord = new CSVRecord();  
        csvRecord.id = curruntRecord[0];  
        csvRecord.uniqueID = curruntRecord[1];  
        csvRecord.enterqueue = curruntRecord[2] 
        csvRecord.connect = curruntRecord[3]  
        csvRecord.caller = curruntRecord[4]  
        csvRecord.hunting = curruntRecord[5] 
        csvRecord.agent = curruntRecord[0];  
        csvRecord.extension = curruntRecord[1];  
        csvRecord.campaign = curruntRecord[2] 
        csvRecord.ivr = curruntRecord[3]  
        csvRecord.wait = curruntRecord[4]  
        csvRecord.coTime = curruntRecord[5] 
        csvRecord.rTime = curruntRecord[1];  
        csvRecord.tTime = curruntRecord[2] 
        csvRecord.rna = curruntRecord[3]  
        csvRecord.transfer = curruntRecord[4]  
        csvRecord.status = curruntRecord[5] 
        csvRecord.cby= curruntRecord[0]; 
        csvRecord.cTime= curruntRecord[0]; 
        csvArr.push(csvRecord);  
      }  
    }  
    return csvArr;  
  }  
  
  isValidCSVFile(file: any) { 
    return file.name.endsWith(".csv");  
  }  
  
  getHeaderArray(csvRecordsArr: any) { 
    this.value= (<string>csvRecordsArr[0]).split(','); 
    let headers = (<string>csvRecordsArr[1]).split(',');  
    let headerArray = [];  
    for (let j = 0; j < headers.length; j++) {  
      headerArray.push(headers[j]);  
    }  
    return headerArray;  
  }  
  
  fileReset() {  
    this.csvReader.nativeElement.value = "";  
    this.records = [];  
  } 
}
