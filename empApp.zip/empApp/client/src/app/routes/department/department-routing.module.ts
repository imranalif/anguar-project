import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddDepartmentComponent } from './add-department/add-department.component';
import { ListDepartmentComponent } from './list-department/list-department.component';
import { UpdateDepartmentComponent } from './update-department/update-department.component';
import { ImportComponent } from './import/import.component';

const routes: Routes = [
  { path: 'add', component: AddDepartmentComponent },
  { path: 'lista', component: ListDepartmentComponent },
  { path: 'edited/:id', component: UpdateDepartmentComponent },
  { path: 'import', component: ImportComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DepartmentRoutingModule {}
