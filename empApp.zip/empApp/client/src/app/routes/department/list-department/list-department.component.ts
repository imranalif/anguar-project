import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import { AppService } from 'app/model/app.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Department } from 'app/model/department.model';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-list-department',
  templateUrl: './list-department.component.html',
  styleUrls: ['./list-department.component.scss'],
})
export class ListDepartmentComponent implements OnInit {
  myform: FormGroup;
  page=1
  config: any;
  pager = {};
  pageOfItems = [];
  data: any=[];
  data1:any=[]
  dept: Department;

  weightes = [{ value: "1" }, { value: "2" }, { value: "3" }, { value: "4" }];
  
  constructor( private changeDetectorRefs: ChangeDetectorRef,private fb: FormBuilder,private _dept: AppService, private route: ActivatedRoute, private _router: Router, private toastr: ToastrService) {
    
  }

  ngOnInit() {
    this.myform = this.fb.group({ currentPage: [""]})
    //this._dept.getDeptByPage(this.page).subscribe(res => (this.data = res));
    this.refresh()
    console.log(this.data)
    //this.route.queryParams.subscribe(x => this.loadPage(x.page || 1));
  }

  displayedColumns = ['id', 'name', 'description', 'status', 'action'];

  editOne(dept) {
    this._router.navigate(['department/edited', dept.id]); //for mongo dept._id
  }

 

  delete(dept) {
    this._dept.deleteDept(dept.id).subscribe(res=>{this.changeDetectorRefs.detectChanges()});
    this.data = this.data.filter(item => item.id != dept.id);
    this.showToast();
  }
  showToast() {
    this.toastr.success(JSON.stringify('Deleted successfully'));
  }



onChange(currentPage){
  this._dept.getDeptByPage(currentPage).subscribe(res => (this.data = res));
}

refresh(){
  this._dept.getDeptByPage(this.page).subscribe(res => {this.data = res,this.changeDetectorRefs.detectChanges()} 
   );
 
}
}
