import { Component, OnInit } from '@angular/core';
import { AppService } from 'app/model/app.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-list-role',
  templateUrl: './list-role.component.html',
  styleUrls: ['./list-role.component.scss']
})
export class ListRoleComponent implements OnInit {
data:{}
  constructor(private _role: AppService, private _router: Router, private toastr: ToastrService) { }

  ngOnInit() {
    this._role.getRole().subscribe(res => (this.data = res));
  }

  displayedColumns = ['id', 'name', 'description', 'status', 'action'];

  editRole(role) {
    this._router.navigate(['role/editRole', role.id]); //for mongo dept._id
  }
}
