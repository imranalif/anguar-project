import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'app/model/app.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.scss']
})
export class AddRoleComponent implements OnInit {
  myform: FormGroup;
  states = [{ value: 'active' }, { value: 'inActive' }];

  constructor(private fb: FormBuilder, private _role: AppService,private toastr: ToastrService) { }

  ngOnInit() {
    this.myform = this.fb.group({
      name: [''],
      description: [''],
      status: [''],
    });
  }

  addRole() {
    console.log(this.myform.value);
    this._role.addRole(this.myform.value).subscribe();
    this.showToast()
  }

  showToast() {
    this.toastr.success(JSON.stringify("Add Successfully"));
  }

}
