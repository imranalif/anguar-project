import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from 'app/model/app.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { Role } from 'app/model/role.model';

@Component({
  selector: 'app-update-role',
  templateUrl: './update-role.component.html',
  styleUrls: ['./update-role.component.scss']
})
export class UpdateRoleComponent implements OnInit {
  myform: FormGroup;
  Id:string
  states = [{ value: 'active' }, { value: 'inActive' }];

  constructor(private fb: FormBuilder,private _router: Router, private _route: ActivatedRoute, private _role: AppService,private toastr: ToastrService) { }

  ngOnInit() {
    this.myform = this.fb.group({
      name: [''],
      description: [''],
      status: [''],
    });

    this._route.paramMap.subscribe(params => {
      this.Id = params.get("id");
      this.edit(this.Id);
    });
  }
  edit(id) {
    this._role.getRoleId(id).subscribe((role: Role) => {
      this.setDept(role);
    });
  }
  setDept(role: Role) {
    //console.log(role[0]); //[0]  added
    this.myform.patchValue({
      name: role.name,
      description: role.description,
      status: role.status
    });
  }

  updateRole() {
    this._role.updateRole(this.Id, this.myform.value).subscribe();
    console.log(this.myform.value);
    this._router.navigate(["role/listRole"]);
  }

}
