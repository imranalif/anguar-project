import { NgModule, APP_INITIALIZER } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NgxPaginationModule } from 'ngx-pagination';

import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { ThemeModule } from './theme/theme.module';
import { RoutesModule } from './routes/routes.module';
import { AppComponent } from './app.component';

import { DefaultInterceptor } from '@core';
import { StartupService } from '@core';
export function StartupServiceFactory(startupService: StartupService) {
  return () => startupService.load();
}

import { FormlyModule } from '@ngx-formly/core';
import { ToastrModule } from 'ngx-toastr';
import { EmployeeModule } from './routes/employee/employee.module';
import { DepartmentModule } from './routes/department/department.module';
import { AppService } from './model/app.service';
import { DeginationModule } from './routes/degination/degination.module';
import { RoleModule } from './routes/role/role.module';
import { LeaveModule } from './routes/leave/leave.module';
import { ShiftModule } from './routes/shift/shift.module';
import { EmployeeRosterModule } from './routes/employee-roster/employee-roster.module';
import { EmployeeShiftModule } from './routes/employee-shift/employee-shift.module';
import { OffdayModule } from './routes/offday/offday.module';
import { PermissionModule } from './routes/permission/permission.module';
import { PermissionGroupModule } from './routes/permission-group/permission-group.module';
import { UniqueItemDirective } from './model/unique-item.directive';
import { MapModule } from './routes/map/map.module';

//import { FileSelectDirective } from 'ng2-file-upload';

@NgModule({
  declarations: [AppComponent, UniqueItemDirective],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    NgxPaginationModule,
    CoreModule,
    SharedModule,
    ThemeModule,
    RoutesModule,
    DepartmentModule,
    DeginationModule,
    RoleModule,
     LeaveModule,
     OffdayModule,
     ShiftModule,
    EmployeeModule,
    EmployeeRosterModule,
    EmployeeShiftModule,
    PermissionModule, 
    PermissionGroupModule,
    MapModule,
    FormlyModule.forRoot(),
    ToastrModule.forRoot(),
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: DefaultInterceptor, multi: true },
    StartupService,
    AppService,
    {
      provide: APP_INITIALIZER,
      useFactory: StartupServiceFactory,
      deps: [StartupService],
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
